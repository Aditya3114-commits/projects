# EC2 Auto Scaling on AWS

A highly available, self-scaling web application on AWS. A **Launch Template** defines how each server is built, and an **Auto Scaling Group (ASG)** keeps between a minimum and maximum number of EC2 instances running across multiple Availability Zones behind an **Application Load Balancer**. A **target tracking scaling policy** adds instances when CPU is high and removes them when load drops. The web server is installed **automatically** on every new instance using a user data script.

## Architecture

```
                 Internet
                    |
                    v
       Application Load Balancer  (HTTP 80 from anywhere)
          |                  |
          v                  v
   EC2 (us-east-1a)    EC2 (us-east-1b)   ...   <- Auto Scaling Group (min 1, desired 2, max 4)
   Apache web server   Apache web server         instances launched from the Launch Template
          |
          v
   CloudWatch (CPU metric -> alarms -> scaling policy -> ASG adds / removes instances)
```

## Tech Stack

| Service | Purpose |
|---|---|
| EC2 Launch Template | Blueprint for every instance (AMI, type, security group, IAM role, user data) |
| EC2 Auto Scaling Group | Maintains capacity and scales out and in automatically |
| Application Load Balancer + Target Group | Distributes traffic and runs health checks |
| Amazon CloudWatch | Metrics and alarms that trigger scaling |
| IAM | Role that lets Session Manager open a shell on instances (used to generate load) |
| Security Groups | Load balancer open on port 80; instances accept traffic only from the load balancer |

**Region:** `us-east-1` (N. Virginia)

## Configuration Summary

| Setting | Value |
|---|---|
| Launch template | `web-server-template` |
| Instance type | t3.micro |
| Operating system | Amazon Linux 2023 |
| Web server | Apache (httpd), installed automatically through user data |
| Auto Scaling Group | `web-asg.` |
| Minimum capacity | 1 |
| Desired capacity | 2 |
| Maximum capacity | 4 |
| Health checks | ELB health checks, grace period 120 seconds |
| Scaling policy | Target tracking: average CPU utilization at 50% |
| Instance warm-up | 60 seconds |
| Load balancer | `web-aplicationloadblancer` (internet-facing, HTTP:80) |

## Setup

### 1. Security groups
- Load balancer security group: inbound HTTP (80) from anywhere
- Instance security group: inbound HTTP (80) **only from the load balancer security group**, so the internet can reach the servers only through the load balancer

<!-- ![Security Groups](images/01-security-groups.png) -->

### 2. IAM role for Session Manager
A role with the `AmazonSSMManagedInstanceCore` policy, attached to the instances so a shell can be opened without opening SSH.

<!-- ![IAM Role](images/02-iam-role.png) -->

### 3. Launch Template
`web-server-template` uses Amazon Linux 2023, t3.micro, the instance security group, the IAM role and detailed monitoring. Apache is installed automatically on boot by the script in [`user-data.sh`](user-data.sh). The page it creates shows the instance ID and Availability Zone that served the request.

<!-- ![Launch Template](images/03-launch-template.png) -->
<!-- ![User Data](images/03b-launch-template-user-data.png) -->

### 4. Target Group
HTTP port 80, target type Instances, health check path `/`. No targets are registered manually, because the Auto Scaling Group registers its instances automatically.

<!-- ![Target Group](images/04-target-group.png) -->

### 5. Application Load Balancer
Internet-facing, spread across multiple Availability Zones, with an HTTP:80 listener forwarding to the target group.

![Load Balancer](images/05-load-balancer.png)

### 6. Auto Scaling Group
Uses `web-server-template`, spans multiple Availability Zones, is attached to the target group, and has ELB health checks enabled. Scaling limits are **minimum 1 and maximum 4**, with a desired capacity of **2**.

![ASG Capacity](images/06-asg-capacity.png)

The group at its desired capacity with both instances healthy:

![ASG Healthy](images/06b-asg-healthy.png)

### 7. Scaling policy
A target tracking policy keeps average CPU utilization near **50%**, with a 60 second instance warm-up. Scale in is enabled.

![Scaling Policy](images/07-scaling-policy.png)

## Verification

EC2 instances launched automatically by the Auto Scaling Group, running in different Availability Zones:

![EC2 Instances](images/08-ec2-instances.png)

Opening the load balancer's DNS name shows the web page. Different requests are served by different instances, in different Availability Zones, which proves the load balancer distributes traffic:

![Web Page, Instance in us-east-1a](images/10-web-page-1.png)

![Web Page, Instance in us-east-1b](images/10b-web-page-2.png)

<!-- ![Healthy Targets](images/09-healthy-targets.png) -->

## Scaling Behavior

### Observed activity (scale in)
The Activity history of the Auto Scaling Group recorded the following (times are IST, 7 October 2026):

| Time | Event |
|---|---|
| 11:31:30 PM | Auto Scaling Group created, desired capacity changed from 0 to 2 |
| 11:31:33 PM | Launch in `us-east-1e` **failed**: `t3.micro` is not supported in that Availability Zone |
| 11:31:33 PM | Instance launched successfully in another Availability Zone |
| 11:31:44 PM | A second instance was launched (capacity 1 to 2) |
| 11:47:50 PM | CloudWatch alarm **AlarmLow** (created by the target tracking policy) triggered, reducing desired capacity from 2 to 1 and terminating one instance, because CPU stayed low |

This confirms the scaling policy works automatically: with almost no load, average CPU was far below the 50% target, so the group removed an unneeded instance.

![Activity History](images/16-activity-scale-in.png)

<!-- SCALE-OUT DEMONSTRATION: add the load test section and screenshots here (CPU load, CloudWatch alarm in ALARM state, activity history, 4 instances, CPU graph). -->

## Key Concepts Learned
- **Launch Template**: a reusable blueprint (AMI, instance type, security group, IAM role, user data) for instances.
- **Minimum / Desired / Maximum**: the group never goes below the minimum or above the maximum, and always tries to keep the desired number running.
- **Target tracking policy**: AWS creates and manages the CloudWatch alarms and adjusts capacity to hold the metric near the target.
- **Health checks**: with ELB health checks, an unhealthy instance is replaced automatically.
- **Warm-up**: new instances need time to start before their metrics count.
- **Scale in is slower than scale out** on purpose, to avoid removing capacity too early.

## Problems I Faced and How I Fixed Them

| Problem | Cause | Fix |
|---|---|---|
| A launch failed with "t3.micro is not supported in us-east-1e" | One of the selected subnets was in an Availability Zone that does not offer t3.micro | The group retried automatically in a supported zone; the unsupported zone's subnet should be removed from the group to avoid repeated failures |
| Only one instance was serving traffic | The scaling policy had scaled in from 2 to 1 because CPU was idle | Set the desired capacity back to 2 and took the load-balancing screenshots before the next scale-in |

## Project Structure

```
ec2-auto-scaling-project/
├── README.md
├── user-data.sh
└── images/
```

## Clean Up (to avoid charges)
Delete in this order:
1. Auto Scaling Group (this terminates its instances)
2. Application Load Balancer
3. Target group
4. Launch template
5. Security groups (instance group first, then load balancer group)
6. IAM role
7. Any instances that were launched manually

## Future Improvements
- Add HTTPS with an ACM certificate on the load balancer
- Add scheduled scaling for predictable traffic
- Scale on request count per target (`ALBRequestCountPerTarget`)
- Use private subnets with a NAT gateway
- Define everything with CloudFormation or Terraform

## Author
**Your Name** | [LinkedIn](https://linkedin.com/in/your-profile) | [GitHub](https://github.com/your-username)
