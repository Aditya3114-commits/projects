#!/bin/bash
# Runs automatically on first boot of every instance launched by the Auto Scaling Group.
# Amazon Linux 2023: installs Apache and creates a page showing which instance served the request.

dnf install -y httpd
systemctl enable --now httpd

# Read instance details from the metadata service (IMDSv2)
TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600")
INSTANCE_ID=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/instance-id)
AZ=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/placement/availability-zone)

cat > /var/www/html/index.html <<HTML
<!DOCTYPE html>
<html>
<head>
  <title>Auto Scaling Demo</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f2f6fc; text-align: center; padding-top: 80px; }
    .card { display: inline-block; background: white; padding: 30px 50px; border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.15); }
    h1 { color: #232f3e; }
    .value { color: #ff9900; font-weight: bold; }
  </style>
</head>
<body>
  <div class="card">
    <h1>EC2 Auto Scaling Demo</h1>
    <p>Served by instance: <span class="value">$INSTANCE_ID</span></p>
    <p>Availability Zone: <span class="value">$AZ</span></p>
    <p>Refresh the page to see the load balancer switch instances.</p>
  </div>
</body>
</html>
HTML
