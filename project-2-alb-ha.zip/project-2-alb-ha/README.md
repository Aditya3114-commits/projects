# Project 2: Highly Available Web Application using ALB and Multiple EC2 Instances

## 1. Objective

Build a highly available web application on AWS using an Application Load Balancer (ALB) in front of two EC2 web servers placed in different Availability Zones. A Target Group with health checks lets the ALB detect an unhealthy server and send traffic only to healthy ones. The project demonstrates that the application stays available when one instance fails and that the instance rejoins after recovery.

## 2. Architecture

```
                     Internet
                        |
        Application Load Balancer (ha-web-alb)
          Internet-facing, us-east-1a + us-east-1b
                        |
              Target Group (ha-web-tg)
              HTTP:80, health check on "/"
                /                   \
   EC2 web-ser 1 (us-east-1a)   EC2 web-ser2 (us-east-1b)
```

> Add your draw.io diagram as `architecture-diagram.png` in this folder and uncomment the next line.
<!-- ![Architecture](architecture-diagram.png) -->

- **ALB** receives HTTP traffic on port 80 and forwards it to the target group.
- **Target Group** registers both instances and runs periodic health checks.
- **EC2 instances** run Apache and serve a page showing their own Instance ID and AZ.
- **Security Groups** restrict access: the internet reaches only the ALB, and the instances accept web traffic from the ALB.

## 3. AWS Services Used

| Service | Purpose |
|---|---|
| Amazon EC2 | Two Amazon Linux 2023 web servers (t3.micro) |
| Elastic Load Balancing (ALB) | Distributes incoming HTTP traffic across instances |
| Target Group | Registers instances and performs health checks |
| Amazon VPC (default) | Network, subnets in two AZs |
| Security Groups | Network access control (`alb-sg`, `web-sg`) |
| AWS CloudShell | Running load balancing and failover tests |
| Amazon CloudWatch (optional) | HealthyHostCount / UnHealthyHostCount metrics |

## 4. Configuration Details

| Item | Value |
|---|---|
| Region | us-east-1 (N. Virginia) |
| VPC | `vpc-0e35ad64371d9d310` (default) |
| AMI / Instance type | Amazon Linux 2023 / t3.micro |
| Instance 1 | `web-ser 1`, `i-0ee2cd118a817b4a9`, us-east-1a |
| Instance 2 | `web-ser2`, `i-04b223e689e2002a1`, us-east-1b |
| Load balancer | `ha-web-alb`, Application, Internet-facing, IPv4, state Active |
| ALB DNS name | `ha-web-alb-2090150807.us-east-1.elb.amazonaws.com` |
| ALB subnets | `subnet-07fa7e45ac0cf7db6` (us-east-1a), `subnet-022386e24aee2ee7f` (us-east-1b) |
| Listener | HTTP:80, forward to `ha-web-tg` (100%) |
| Target group | `ha-web-tg`, Instance targets, HTTP:80 |
| Health check | Path `/`, success code 200. **TODO: fill in interval / timeout / thresholds from the Health checks tab** |
| ALB security group | `alb-sg` (`sg-0264164e852a255ff`): HTTP 80 from the internet |
| Instance security group | `web-sg` (`sg-07966e16c1efd42f5`): HTTP 80 from `alb-sg` |

### Instances in two Availability Zones

![Instances](screenshots/01-instances-two-azs.png)

### Security groups

`alb-sg` inbound rules:

![alb-sg](screenshots/02a-alb-sg-inbound.png)

`web-sg` inbound rules:

![web-sg](screenshots/02b-web-sg-inbound.png)

### Load balancer and listener

![ALB details](screenshots/04-alb-details-listener.png)

### User data (runs at launch on both instances)

```bash
#!/bin/bash
dnf update -y
dnf install -y httpd
systemctl enable --now httpd

TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" \
  -H "X-aws-ec2-metadata-token-ttl-seconds: 21600")
INSTANCE_ID=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
  http://169.254.169.254/latest/meta-data/instance-id)
AZ=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
  http://169.254.169.254/latest/meta-data/placement/availability-zone)

cat > /var/www/html/index.html <<EOF
<html><body style="font-family:sans-serif;text-align:center;margin-top:80px">
<h1>Highly Available Web App</h1>
<h2>Served by: ${INSTANCE_ID}</h2>
<h3>Availability Zone: ${AZ}</h3>
</body></html>
EOF
```

## 5. Implementation Steps

1. Created security groups `alb-sg` (HTTP from internet) and `web-sg` (HTTP from `alb-sg`).
2. Launched two t3.micro Amazon Linux 2023 instances in different AZs (us-east-1a and us-east-1b) with the user data script above.
3. Created target group `ha-web-tg` (HTTP:80, health check path `/`) and registered both instances.
4. Created Internet-facing ALB `ha-web-alb` across both AZs with security group `alb-sg` and an HTTP:80 listener forwarding to `ha-web-tg`.
5. Verified both targets were healthy and that traffic alternates between the two instances.
6. Simulated failure of one instance, observed traffic continuing on the healthy one, then recovered the instance.

## 6. Testing & Results

### Test 1: Both targets healthy

Target group `ha-web-tg` shows 2 registered targets, both **Healthy**, one in us-east-1a and one in us-east-1b.

![Targets healthy](screenshots/05-targets-healthy.png)

![Registered targets](screenshots/05b-target-group-registered-targets.png)

### Test 2: Load balancing across instances

Command (run from AWS CloudShell):

```bash
for i in $(seq 1 10); do curl -s http://ha-web-alb-2090150807.us-east-1.elb.amazonaws.com | grep "Served by"; done
```

Result: both `i-04b223e689e2002a1` and `i-0ee2cd118a817b4a9` answered, so the ALB distributes requests across both servers.

![Loop output](screenshots/07-loop-both-ids.png)

> TODO: add browser screenshots of Instance A and Instance B (`06a-browser-instance-a.png`, `06b-browser-instance-b.png`).

### Test 3: Failover (one instance made unavailable)

A continuous test was run while one instance was stopped:

```bash
while true; do
  echo "$(date +%T) $(curl -s -m 3 -o /dev/null -w '%{http_code}' http://ha-web-alb-2090150807.us-east-1.elb.amazonaws.com) $(curl -s -m 3 http://ha-web-alb-2090150807.us-east-1.elb.amazonaws.com | grep -o 'i-[a-z0-9]*')"
  sleep 1
done
```

Observed output after the failed instance was marked unhealthy:

```
17:25:34 200 i-0ee2cd118a817b4a9
17:25:35 200 i-0ee2cd118a817b4a9
...
17:25:41 200 i-0ee2cd118a817b4a9
```

Every request returned HTTP 200 and was served only by the healthy instance `i-0ee2cd118a817b4a9`, so users saw no outage.

> TODO: add screenshots `08-instance-stopped.png`, `09-target-unhealthy.png`, `10-failover-log.png`, `11-browser-during-failure.png`.

### Test 4: Recovery

The stopped instance was started again. After it passed the health checks the target returned to **Healthy** and both instance IDs appeared in the loop output again.

> TODO: add `12-recovery-healthy.png` and note the recovery time.

### Summary table

| Test | Action | Expected | Actual |
|---|---|---|---|
| Health | Registered both instances | Both healthy | 2/2 Healthy |
| Load balancing | 10 requests to ALB DNS | Both IDs appear | Both IDs appear |
| Failover | Stopped one instance | Traffic continues on healthy instance | 100% HTTP 200 from `i-0ee2cd118a817b4a9` |
| Recovery | Started instance again | Target returns to healthy | TODO |

## 7. Challenges & Fixes

| Problem | Cause | Fix |
|---|---|---|
| ALB URL timed out (`curl: (28) Connection timed out`) | Inbound rules on `alb-sg` did not allow web traffic from the internet | Modified the inbound rules of `alb-sg`; afterwards the ALB returned `HTTP 200` |
| Loop printed nothing | `curl -s` hid the error and `grep` found no match | Ran `curl -i` to see the real response |

## 8. Cost & Cleanup

The ALB bills hourly, so resources were deleted after testing, in this order:

1. Load balancer `ha-web-alb`
2. Target group `ha-web-tg`
3. Both EC2 instances (terminated)
4. Security groups `web-sg`, then `alb-sg`

## 9. Conclusion

The ALB spreads traffic across two EC2 instances in separate Availability Zones, and health checks remove a failed instance from rotation automatically. When one server was stopped the application kept responding with HTTP 200 through the other server, and the failed instance rejoined after recovery. This demonstrates a highly available design with no single point of failure at the instance level.
