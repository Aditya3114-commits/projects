import json
import os
from decimal import Decimal

import boto3
from botocore.exceptions import ClientError

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(os.environ.get("TABLE_NAME", "Students"))

REQUIRED_FIELDS = ["student_id", "name", "email", "course", "age"]
UPDATABLE_FIELDS = ["name", "email", "course", "age"]


class DecimalEncoder(json.JSONEncoder):
    """DynamoDB returns numbers as Decimal; convert them for JSON."""

    def default(self, o):
        if isinstance(o, Decimal):
            return int(o) if o % 1 == 0 else float(o)
        return super().default(o)


def response(status, body):
    return {
        "statusCode": status,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body, cls=DecimalEncoder),
    }


def parse_body(event):
    try:
        return json.loads(event.get("body") or "{}")
    except json.JSONDecodeError:
        return None


def valid_age(age):
    return isinstance(age, int) and not isinstance(age, bool) and 0 < age < 120


# ---------- CRUD operations ----------

def add_student(event):
    data = parse_body(event)
    if data is None:
        return response(400, {"message": "Invalid JSON body"})

    missing = [f for f in REQUIRED_FIELDS if f not in data or data[f] in ("", None)]
    if missing:
        return response(400, {"message": f"Missing fields: {', '.join(missing)}"})
    if not valid_age(data["age"]):
        return response(400, {"message": "age must be a whole number between 1 and 119"})

    item = {f: data[f] for f in REQUIRED_FIELDS}
    try:
        table.put_item(
            Item=item,
            ConditionExpression="attribute_not_exists(student_id)",
        )
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
            return response(409, {"message": "Student with this ID already exists"})
        raise
    return response(201, {"message": "Student added successfully", "student": item})


def list_students(event):
    items, kwargs = [], {}
    while True:
        result = table.scan(**kwargs)
        items.extend(result.get("Items", []))
        if "LastEvaluatedKey" not in result:
            break
        kwargs["ExclusiveStartKey"] = result["LastEvaluatedKey"]
    return response(200, {"count": len(items), "students": items})


def get_student(event):
    student_id = event["pathParameters"]["id"]
    result = table.get_item(Key={"student_id": student_id})
    if "Item" not in result:
        return response(404, {"message": "Student not found"})
    return response(200, result["Item"])


def update_student(event):
    student_id = event["pathParameters"]["id"]
    data = parse_body(event)
    if data is None:
        return response(400, {"message": "Invalid JSON body"})

    updates = {k: v for k, v in data.items() if k in UPDATABLE_FIELDS}
    if not updates:
        return response(400, {"message": f"Provide at least one of: {', '.join(UPDATABLE_FIELDS)}"})
    if "age" in updates and not valid_age(updates["age"]):
        return response(400, {"message": "age must be a whole number between 1 and 119"})

    # '#' placeholders avoid clashes with DynamoDB reserved words (e.g. "name")
    set_parts = [f"#{k} = :{k}" for k in updates]
    names = {f"#{k}": k for k in updates}
    values = {f":{k}": v for k, v in updates.items()}

    try:
        result = table.update_item(
            Key={"student_id": student_id},
            UpdateExpression="SET " + ", ".join(set_parts),
            ExpressionAttributeNames=names,
            ExpressionAttributeValues=values,
            ConditionExpression="attribute_exists(student_id)",
            ReturnValues="ALL_NEW",
        )
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
            return response(404, {"message": "Student not found"})
        raise
    return response(200, {"message": "Student updated successfully", "student": result["Attributes"]})


def delete_student(event):
    student_id = event["pathParameters"]["id"]
    try:
        table.delete_item(
            Key={"student_id": student_id},
            ConditionExpression="attribute_exists(student_id)",
        )
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
            return response(404, {"message": "Student not found"})
        raise
    return response(200, {"message": "Student deleted successfully"})


# ---------- Router ----------

ROUTES = {
    "POST /students": add_student,
    "GET /students": list_students,
    "GET /students/{id}": get_student,
    "PUT /students/{id}": update_student,
    "DELETE /students/{id}": delete_student,
}


def lambda_handler(event, context):
    route_key = event.get("routeKey")
    handler = ROUTES.get(route_key)
    if handler is None:
        return response(404, {"message": f"Route not found: {route_key}"})
    try:
        return handler(event)
    except Exception as e:  # log the real error, return a generic one
        print(f"ERROR: {e}")
        return response(500, {"message": "Internal server error"})
