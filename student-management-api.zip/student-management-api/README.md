# Serverless Student Management API

A fully serverless REST API to **add, view, update and delete student records**, built with **AWS Lambda**, **Amazon API Gateway (HTTP API)** and **Amazon DynamoDB**. There are no servers to manage, and you pay only for what you use.

## Architecture

```
Client (Postman / curl / browser)
            |
            v
Amazon API Gateway (HTTP API)
            |
            v
AWS Lambda (Python 3.12)  ---->  Amazon DynamoDB (students table)
            |
            v
Amazon CloudWatch Logs
```

## Tech Stack

| Service | Purpose |
|---|---|
| AWS Lambda | Runs the API logic (Python 3.12, boto3) |
| Amazon API Gateway | Exposes the HTTP endpoints (HTTP API, payload format 2.0) |
| Amazon DynamoDB | NoSQL database storing student records |
| AWS IAM | Grants Lambda least-privilege access to the table |
| Amazon CloudWatch | Logs and debugging |

**Region used:** `us-east-1` (N. Virginia)

## API Endpoints

| Method | Endpoint | Description | Success code |
|---|---|---|---|
| POST | `/students` | Add a new student | 201 |
| GET | `/students` | View all students | 200 |
| GET | `/students/{id}` | View one student | 200 |
| PUT | `/students/{id}` | Update a student | 200 |
| DELETE | `/students/{id}` | Delete a student | 200 |

Error codes: `400` invalid or missing data, `404` student not found, `409` duplicate student ID, `500` server error.

## Student Record

| Field | Type | Notes |
|---|---|---|
| `student_id` | String | Partition key, must be unique |
| `name` | String | Required |
| `email` | String | Required |
| `course` | String | Required |
| `age` | Number | Required, whole number from 1 to 119 |

## Setup

### 1. Create the DynamoDB table
- Table name: `students`
- Partition key: `student_id` (String)
- Capacity mode: On-demand

![DynamoDB Table](images/01-dynamodb-table.png)

### 2. Create the Lambda function
- Name: `student-management-api`, runtime Python 3.12
- Paste the code from [`lambda_function.py`](lambda_function.py) and click **Deploy**
- Environment variable: `TABLE_NAME = students`
- Timeout: 10 seconds

![Lambda Function](images/02-lambda-function.png)

![Lambda Code Deployed](images/02b-lambda-code-deployed.png)

![Lambda Environment Variables](images/02c-lambda-env-vars.png)

### 3. Give Lambda permission to access DynamoDB
An inline policy (`studentstableaccess`) is added to the Lambda execution role, allowing only the five actions the API needs on this one table:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "dynamodb:PutItem",
        "dynamodb:GetItem",
        "dynamodb:UpdateItem",
        "dynamodb:DeleteItem",
        "dynamodb:Scan"
      ],
      "Resource": "arn:aws:dynamodb:us-east-1:<ACCOUNT_ID>:table/students"
    }
  ]
}
```

![IAM Permissions](images/03-iam-permissions.png)

### 4. Create the HTTP API in API Gateway
Five routes, all integrated with the Lambda function:

![API Routes](images/04-api-routes.png)

The API is deployed to the `$default` stage with auto-deploy enabled:

![Invoke URL](images/05-invoke-url.png)

A quick check in the browser (`GET /students` on an empty table) confirms that API Gateway, Lambda and DynamoDB are connected:

![Quick Test](images/05b-quick-test.png)

## Testing the APIs

Replace the URL with your own Invoke URL:

```bash
export API_URL="https://<api-id>.execute-api.us-east-1.amazonaws.com"
```

### 1. Add students: `POST /students`

```bash
curl -X POST $API_URL/students -H "Content-Type: application/json" \
  -d '{"student_id":"S001","name":"Rahul Sharma","email":"rahul@example.com","course":"Computer Science","age":20}'

curl -X POST $API_URL/students -H "Content-Type: application/json" \
  -d '{"student_id":"S002","name":"Priya Patil","email":"priya@example.com","course":"Information Technology","age":21}'

curl -X POST $API_URL/students -H "Content-Type: application/json" \
  -d '{"student_id":"S003","name":"Amit Kulkarni","email":"amit@example.com","course":"Mechanical Engineering","age":22}'
```

Expected: `201 Created`

```json
{"message": "Student added successfully", "student": {"student_id": "S001", "name": "Rahul Sharma", "email": "rahul@example.com", "course": "Computer Science", "age": 20}}
```

![POST Test](images/06-post-test.png)

### 2. View all students: `GET /students`

```bash
curl $API_URL/students
```

Expected: `200 OK` with `"count": 3`.

![GET All](images/07-get-all.png)

### 3. View one student: `GET /students/{id}`

```bash
curl $API_URL/students/S001
```

![GET One](images/08-get-one.png)

### 4. Update a student: `PUT /students/{id}`

```bash
curl -X PUT $API_URL/students/S001 -H "Content-Type: application/json" \
  -d '{"course":"Artificial Intelligence","age":21}'
```

![PUT Test](images/09-put-test.png)

### 5. Delete a student: `DELETE /students/{id}`

```bash
curl -X DELETE $API_URL/students/S003
```

![DELETE Test](images/10-delete-test.png)

### 6. Error handling tests

| Test | Request | Expected |
|---|---|---|
| Student not found | `GET /students/S003` (after delete) | `404 Not Found` |
| Duplicate ID | `POST` with `S001` again | `409 Conflict` |
| Missing field | `POST {"student_id":"S004","name":"Test"}` | `400 Bad Request` |
| Update missing student | `PUT /students/S999` | `404 Not Found` |

![Error Tests](images/11-error-tests.png)

### 7. Data stored in DynamoDB

![DynamoDB Items](images/12-dynamodb-items.png)

### 8. CloudWatch logs

![CloudWatch Logs](images/13-cloudwatch-logs.png)

## Key Design Decisions
- **One Lambda function with a router**: the function reads API Gateway's `routeKey` (for example `GET /students/{id}`) and calls the matching handler, which keeps a small project simple.
- **Conditional writes**: `attribute_not_exists` prevents overwriting a student on POST (409), and `attribute_exists` returns a proper 404 on PUT and DELETE.
- **Least-privilege IAM**: the role can only run five DynamoDB actions on the one table.
- **Input validation**: required fields and age range are checked before writing.

## Problems I Faced and How I Fixed Them

| Problem | Cause | Fix |
|---|---|---|
| `AccessDeniedException` on Scan | IAM policy missing or had placeholder values | Created the inline policy with the real region and account ID |
| `ResourceNotFoundException` | Table name was `students` but the code and policy used `Students` (DynamoDB names are case-sensitive) | Made `TABLE_NAME` and the policy ARN match the real table name |
| Policy editor red error | `<REGION>` and `<ACCOUNT_ID>` placeholders left in the ARN | Replaced them with real values |

## Project Structure

```
student-management-api/
├── lambda_function.py
├── README.md
└── images/
```

## Clean Up
To avoid charges, delete the API Gateway API, the Lambda function, the DynamoDB table, its CloudWatch log group and the IAM role.

## Future Improvements
- Add authentication (Amazon Cognito or API keys)
- Add pagination to `GET /students`
- Deploy with AWS SAM or Terraform
- Add CI/CD with GitHub Actions

## Author
**Your Name** | [LinkedIn](https://linkedin.com/in/your-profile) | [GitHub](https://github.com/your-username)
